var Blynk = require("blynk-library");
var AUTH = 'czwoPVm7VDZD8l8YpWUea7Fm8F5hhxCt';
var blynk =new Blynk.Blynk(AUTH);
var v1 =new blynk.VirtualPin(1);

// v1 write call back
v1.on('write', function(param){
console.log('V1:', param[0]);
if (param[0]==1){
        var spawn = require("child_process").spawn;
	var process = spawn('python',["act_open_noLdr.py"]);
    }

if (param[0]==2){
        var spawn = require("child_process").spawn;
	var process = spawn('python',["act_close_noLdr.py"]);
    }


if (param[0]==3){
        var spawn = require("child_process").spawn;
	var process = spawn('python',["timer_noLdr.py"]);
    }


});