#IMPORTS
import time
import piplates.MOTORplate as MOTOR

#CONFIGURE MOTOR
#motor ports = 0,2), direction = clockWise
#duty cycle = 50%, acceleration = 2.5secs 
MOTOR.dcCONFIG(0,2,'cw',40.0,2.5)

#START THE MOTOR
MOTOR.dcSTART(0,2)

#DELAY 2.5seconds
time.sleep(2.5)     

#INCREASE THE DUTY CYCLE(speed) to 60%
MOTOR.dcSPEED(0,2,60.0)

#DELAY 10seconds
time.sleep(10)

#STOP THE MOTOR
MOTOR.dcSTOP(0,2)

#DELAY 2.5seconds TO WAIT FOR DECELERATION
time.sleep(2.5)
print "DC Motor demo completed"              



