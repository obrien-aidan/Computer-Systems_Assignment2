#IMPORTS
import time
import piplates.MOTORplate as MOTOR

#TIME CONFIG
timeLocal = time.localtime()
hour = timeLocal.tm_hour

#MAIN
#while loop to keep main code running
while 1:
	#IF IT IS 9:00 THEN OPEN
    if hour >= 9:
       MOTOR.dcCONFIG(0,2,'ccw',40.0,2.5)
       MOTOR.dcSTART(0,2)
       time.sleep(2.5)
       MOTOR.dcSPEED(0,2,60.0)
       time.sleep(10)
       MOTOR.dcSTOP(0,2)
       time.sleep(2.5)

    #IF IT IS 21:00 THEN CLOSE  
    if hour <= 21:
       MOTOR.dcCONFIG(0,2,'cw',40.0,2.5)
       MOTOR.dcSTART(0,2)
       time.sleep(2.5)
       MOTOR.dcSPEED(0,2,60.0)
       time.sleep(10)
       MOTOR.dcSTOP(0,2)
       time.sleep(2.5)

