#IMPORTS
import time
import piplates.MOTORplate as MOTOR
from gpiozero import LightSensor 


#LIGHT DEPENDANT RESISTOR SETUP (GPIO-PIN4)
ldr = LightSensor(4)

#TOGGLE SWITCH
state_toggle=1 

#MOTOR
def motorGO():
    MOTOR.dcCONFIG(0,2,'ccw',50.0,2.5)           
    MOTOR.dcSTART(0,2) #Start DC motor
    time.sleep(1.0) #delay 1 seconds
    MOTOR.dcSPEED(0,2,70.0) #increase speed to 70%                           


#MAIN LOOP *NOT WORKING*
# my idea here was to have a 'toggle' that would allow the motor state to change depending on the LDR value
# I could not get it to work
while 1:
    if ldr.value>0.5:
        motorGO()
    elif ldr.value<0.5:
        while 1:
            if(state_toggle==1):
                MOTOR.dcSTOP(0,2)
                state_toggle=0
             
            time.sleep(5)
            if ldr.value>0.5:
                motorGO()
                state_toggle=1

MOTOR.dcSTOP(0,2)
print("expanded")
