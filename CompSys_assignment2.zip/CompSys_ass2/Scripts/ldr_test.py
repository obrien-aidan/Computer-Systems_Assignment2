from gpiozero import LightSensor
import time

ldr = LightSensor(4)


while 1:
    print time.asctime()
    print ldr.value
    print 
    time.sleep(2.5)
