import time
import piplates.MOTORplate as MOTOR

MOTOR.dcCONFIG(0,2,'ccw',50.0,2.5)
MOTOR.dcSTART(0,2)
time.sleep(2.5)
MOTOR.dcSPEED(0,2,60.0)
time.sleep(10)
MOTOR.dcSTOP(0,2)
time.sleep(2.5)
print "test completed"
